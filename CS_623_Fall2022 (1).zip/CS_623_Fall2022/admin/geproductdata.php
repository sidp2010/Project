<!--  Pharmaceutical Tablets Packaging Company
@author Yakshita B Rakholiya(U01875270)-Pace University
@version 2022.10.25 -->
<?php 	

include('includes/dbconnection.php');

$productId = $_POST['productId'];


$sql = "SELECT ProductName,ID,Price FROM tblproducts WHERE ID = $productId";
$result = $con->query($sql);

if($result->num_rows > 0) { 
 $row = $result->fetch_array();
} // if num_rows

$con->close();

echo json_encode($row);