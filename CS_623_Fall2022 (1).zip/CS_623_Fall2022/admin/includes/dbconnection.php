<!--  Pharmaceutical Tablets Packaging Company
@author Yakshita B Rakholiya(U01875270)-Pace University
@version 2022.10.25 -->
<?php
$con=mysqli_connect("Localhost", "root", "", "inventorydb");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
