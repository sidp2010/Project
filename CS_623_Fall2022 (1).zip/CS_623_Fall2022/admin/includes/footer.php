<!--  Pharmaceutical Tablets Packaging Company
@author Yakshita B Rakholiya(U01875270)-Pace University
@version 2022.10.25 -->
<div class="row-fluid">
  <div id="footer" class="span12"> 2022 &copy; Warehouse Management System  </div>
</div>