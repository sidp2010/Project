<!--  Pharmaceutical Tablets Packaging Company
@author Yakshita B Rakholiya(U01875270)-Pace University
@version 2022.10.25 -->
<?php
session_start();
session_unset();
session_destroy();
header('location:login.php');

?>